# COVID-19 vs S&P500

### ToDo:

- Stocks API's integration
- COVID-19's integration
- Charts
- Home page
- S&P 500 page