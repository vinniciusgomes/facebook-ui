import styled from 'styled-components';

export const Container = styled.div`
  background: #fff;
  margin: 5px;
  padding: 5px;
`;
